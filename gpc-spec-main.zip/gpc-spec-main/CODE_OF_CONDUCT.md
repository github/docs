As a W3C Community Group, all work and communication within the Privacy
CG is covered by the
[W3C Code of Ethics and Professional Conduct](https://www.w3.org/Consortium/cepc/).