# Mobilinux-Release
All the app releases are hosted here
