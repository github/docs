# Description

(Please describe your issue or feature request, in detail, here.)

# How to Reproduce

(Please give a step-by-step guide on how to reproduce the issue you are having. Remove this if it's a feature request.)

# Device Information

(Please put as much information on your web browser, device, and Eclipse install. If you want this pre-filled, please use
the debugger to export this data, as described on https://github.com/iGBAEmu/EclipseIssues/blob/master/README.md#debugging)
