import argparse
import time
import requests
from selenium import webdriver
from PIL import Image
import imagehash
import io

def capture_screenshot(url, headers=None):
    options = webdriver.ChromeOptions()
    options.add_argument(''--headless'')
    options.add_argument(''--no-sandbox'')
    options.add_argument(''--disable-dev-shm-usage'')
    driver = webdriver.Chrome(options=options)
    if headers:
        # Inject headers via fake HTTP headers (requires browser-specific workaround)
        # For simplicity, assume headers handled via login or query
        pass
    try:
        driver.get(url)
        time.sleep(3)  # Allow page render
        png = driver.get_screenshot_as_png()
        return Image.open(io.BytesIO(png))
    finally:
        driver.quit()

def compute_hash(img):
    return imagehash.phash(img)

def post_webhook(webhook_url, data):
    try:
        requests.post(webhook_url, json=data, timeout=10)
    except requests.RequestException as e:
        print(f"Webhook failed: {e}")

def main(url, webhook_url, interval, threshold, headers=None):
    last_hash = None
    print(f"Monitoring {url} every {interval}s. Threshold: {threshold}")
    while True:
        try:
            img = capture_screenshot(url, headers)
            img_hash = compute_hash(img)
            if last_hash and img_hash - last_hash > threshold:
                data = {
                    ''status'': ''change_detected'',
                    ''timestamp'': time.strftime(''%Y-%m-%dT%H:%M:%SZ'', time.gmtime()),
                    ''url'': url,
                    ''image_hash'': str(img_hash)
                }
                post_webhook(webhook_url, data)
                last_hash = img_hash
            elif last_hash is None:
                last_hash = img_hash
                print("Baseline set.")
            else:
                print(f"No change: diff={img_hash - last_hash}")
        except Exception as e:
            print(f"Error: {e}")
        time.sleep(interval)

if __name__ == ''__main__'':
    parser = argparse.ArgumentParser(description=''Monitor URL for visual changes.'')
    parser.add_argument(''--url'', required=True, help=''URL to monitor'')
    parser.add_argument(''--webhook'', required=True, help=''Webhook URL to alert'')
    parser.add_argument(''--interval'', type=int, default=300, help=''Check interval in seconds'')
    parser.add_argument(''--threshold'', type=int, default=10, help=''Image hash diff threshold'')
    parser.add_argument(''--headers'', help=''JSON headers (e.g., auth)'')
    args = parser.parse_args()
    main(args.url, args.webhook, args.interval, args.threshold, args.headers)