# Security Policy

## Supported Versions

We support the past two Go releases (for example, Go 1.12.x and Go 1.13.x).

See https://golang.org/wiki/Go-Release-Cycle and in particular the
[Release Maintenance](https://github.com/golang/go/wiki/Go-Release-Cycle#release-maintenance)
part of that page.

## Reporting a Vulnerability

See https://golang.org/security for how to report a vulnerability.
