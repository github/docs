using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("GitLab.Tests")]
