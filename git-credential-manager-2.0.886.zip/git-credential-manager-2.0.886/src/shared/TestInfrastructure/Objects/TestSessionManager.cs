
namespace GitCredentialManager.Tests.Objects
{
    public class TestSessionManager : ISessionManager
    {
        public bool IsDesktopSession { get; set; }
    }
}
