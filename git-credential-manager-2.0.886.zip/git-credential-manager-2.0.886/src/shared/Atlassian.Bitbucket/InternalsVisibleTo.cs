using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Atlassian.Bitbucket.Tests")]
