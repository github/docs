﻿using System.Windows.Controls;

namespace GitHub.UI.Controls
{
    public partial class HorizontalShadowDivider : UserControl
    {
        public HorizontalShadowDivider()
        {
            InitializeComponent();
        }
    }
}