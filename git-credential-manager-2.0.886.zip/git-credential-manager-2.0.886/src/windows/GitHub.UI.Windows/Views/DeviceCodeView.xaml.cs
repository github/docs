using System;
using System.Windows.Controls;
using System.Windows.Threading;

namespace GitHub.UI.Views
{
    public partial class DeviceCodeView : UserControl
    {
        public DeviceCodeView()
        {
            InitializeComponent();
        }
    }
}
