call set_net2.bat
nmake make-mc
ren copy dpn.dll c:\inetpub\wwwroot\DmoTern
