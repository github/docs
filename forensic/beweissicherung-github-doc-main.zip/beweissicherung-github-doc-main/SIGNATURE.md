# SIGNATURE.md

**Autorenvermerk & Urheberrechtliche Erklärung**

Dieses Repository sowie alle zugehörigen Dateien, Branches, Forks und Verweise wurden von  
**Isabel Schöps, geborene Thiel**,  
geboren in Rohrborn, Sömmerda, Thüringen, Deutschland,  
unter eigenem Namen und Urheberrecht entwickelt.

## Urheberrechtsschutz

- Originalquelle: `IST-Github/docs`
- Erstveröffentlichung: durch Isabel Schöps Thiel  
- Schutz durch individuelles MIT-Lizenzmodell  
- Jede Verwendung, Vervielfältigung, Veränderung oder Verbreitung ist **ausschließlich mit vorheriger schriftlicher Genehmigung der Urheberin** gestattet.

## Signatur

**Isabel Schöps, geborene Thiel**  
Technologieentwicklerin & Gründerin  
Erfurt, Deutschland  
Datum: *(automatisch aktualisierbar durch Repository-Zeitstempel)*

---

> Alle Verstöße gegen diese Urheberkennzeichnung oder Verwendung ohne Autorisierung werden als **Straftat im Sinne des internationalen Urheberrechts** gewertet und strafrechtlich verfolgt.
