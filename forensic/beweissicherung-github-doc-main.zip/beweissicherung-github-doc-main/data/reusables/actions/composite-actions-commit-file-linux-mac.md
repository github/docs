```shell copy
git add goodbye.sh
git commit -m "Add goodbye script"
git push
```
