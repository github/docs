> [!WARNING]
> This {% data variables.product.prodname_actions_runner_controller %} customization option may be outside the scope of what {% data variables.contact.github_support %} can assist with and may cause unexpected behavior when configured incorrectly.
>
> For more information about what {% data variables.contact.github_support %} can assist with, see [AUTOTITLE](/actions/hosting-your-own-runners/managing-self-hosted-runners-with-actions-runner-controller/about-support-for-actions-runner-controller).
