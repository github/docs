{% data variables.product.prodname_actions %} usage metrics do not apply minute multipliers to the metrics displayed. While they _can_ help you understand your bill, their primary purpose is to help you understand how and where Actions minutes are being used in your organization.

For more information about minute multipliers, see [AUTOTITLE](/billing/managing-billing-for-github-actions/about-billing-for-github-actions#minute-multipliers).
