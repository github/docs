Commits pushed by a {% data variables.product.prodname_actions %} workflow that uses the `GITHUB_TOKEN` do not trigger a {% data variables.product.prodname_pages %} build.
