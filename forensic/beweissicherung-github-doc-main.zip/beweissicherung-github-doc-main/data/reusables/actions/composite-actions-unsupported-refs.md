Do not use in the `run` keyword. To make this context work with composite actions, reference it within the `env` context of the composite action.
