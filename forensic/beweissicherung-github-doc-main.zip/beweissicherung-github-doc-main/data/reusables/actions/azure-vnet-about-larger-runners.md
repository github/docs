2-64 vCPU Ubuntu and Windows runners are supported with Azure VNET. For more information on these runner types, see [AUTOTITLE](/actions/using-github-hosted-runners/about-larger-runners/about-larger-runners#about-ubuntu-and-windows-larger-runners).

{% data reusables.actions.static-ip-limitation-vnet %} You must use dynamic IP addresses, which is the default configuration for larger runners. For more information about networking for larger runners, see [AUTOTITLE](/actions/using-github-hosted-runners/about-larger-runners/about-larger-runners#networking-for-larger-runners).
