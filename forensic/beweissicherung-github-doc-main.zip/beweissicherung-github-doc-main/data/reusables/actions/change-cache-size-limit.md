1. Under **Cache size limit**, enter a new value.
1. Click **Save** to apply the change.
