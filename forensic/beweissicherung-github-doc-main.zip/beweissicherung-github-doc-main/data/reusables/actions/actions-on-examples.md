### Using a single event

{% data reusables.actions.on-single-example %}

### Using multiple events

{% data reusables.actions.on-multiple-example %}

### Using activity types

{% data reusables.actions.actions-activity-types %}

### Using filters

{% data reusables.actions.actions-filters %}

### Using activity types and filters with multiple events

{% data reusables.actions.actions-multiple-types %}
