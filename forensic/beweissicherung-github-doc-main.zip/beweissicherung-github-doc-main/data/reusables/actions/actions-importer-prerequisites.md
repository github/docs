* An environment where you can run Linux-based containers, and can install the necessary tools.
  * Docker is [installed](https://docs.docker.com/get-docker/) and running.
  * [{% data variables.product.prodname_dotcom %} CLI](https://cli.github.com) is installed.

  > [!NOTE]
  > The {% data variables.product.prodname_actions_importer %} container and CLI do not need to be installed on the same server as your CI platform.
