{% data reusables.actions.settings-sidebar-actions-runner-groups-selection %}
1. Enter the new runner group name in the text field under "Group name."
1. Click **Save**.
