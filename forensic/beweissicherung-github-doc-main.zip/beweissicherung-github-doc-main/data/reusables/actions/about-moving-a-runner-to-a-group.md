If you don't specify a runner group during the registration process, your new runners are automatically assigned to the default group, and can then be moved to another group.
