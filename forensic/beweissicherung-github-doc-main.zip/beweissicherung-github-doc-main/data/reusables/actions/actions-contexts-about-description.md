Contexts are a way to access information about workflow runs, variables, runner environments, jobs, and steps.
