The account ID of the person or app that triggered the initial workflow run. For example, `1234567`. Note that this is different from the actor username.
