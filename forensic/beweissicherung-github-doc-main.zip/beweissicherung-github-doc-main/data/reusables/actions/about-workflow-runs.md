A workflow run is an instance of your workflow that runs when the pre-configured event occurs.
