> [!NOTE]
> Name patterns must be configured for branches or tags individually.
