```shell copy
chmod +x goodbye.sh
```
