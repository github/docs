1. In the "Auto-scaling" section, under "Maximum Job Concurrency," enter the maximum number of jobs you would like to allow to run at the same time.
1. Click **Save**.
