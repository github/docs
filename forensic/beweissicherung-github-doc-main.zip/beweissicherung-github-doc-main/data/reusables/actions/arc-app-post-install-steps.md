1. After creating the {% data variables.product.prodname_github_app %}, on the {% data variables.product.prodname_github_app %}'s page, note the value for "App ID". You will use this value later.
1. Under "Private keys", click **Generate a private key**, and save the `.pem` file. You will use this key later.
