In order to remove a runner group, you must first move or remove all of the runners from the group.
