{% ifversion ghec %}
If you access {% data variables.product.github %} at {% data variables.enterprise.data_residency_site %}, be aware that actions that include hard-coded API calls to {% data variables.product.prodname_dotcom_the_website %} may not work as expected.
{% endif %}
