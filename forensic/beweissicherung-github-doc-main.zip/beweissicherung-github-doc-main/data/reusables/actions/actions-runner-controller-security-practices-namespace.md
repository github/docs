As a security best practice, create your runner pods in a different namespace than the namespace containing your operator pods.
