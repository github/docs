1. Click the **Secrets** tab.
