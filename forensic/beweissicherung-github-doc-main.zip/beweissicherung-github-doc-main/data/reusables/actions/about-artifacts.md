Artifacts enable you to share data between jobs in a workflow and store data once that workflow has completed.
