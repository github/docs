If you use both the `branches` filter and the `paths` filter, the workflow will only run when both filters are satisfied.
