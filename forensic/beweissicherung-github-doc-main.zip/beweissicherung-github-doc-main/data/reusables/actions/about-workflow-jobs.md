A workflow job is a set of steps that execute on the same runner.
