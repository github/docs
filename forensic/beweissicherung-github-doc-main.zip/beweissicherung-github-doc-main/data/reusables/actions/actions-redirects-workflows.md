> [!NOTE]
> To enhance security, {% data variables.product.prodname_actions %} does not support redirects for actions or reusable workflows. This means that when the owner, name of an action's repository, or name of an action is changed, any workflows using that action with the previous name will fail.
