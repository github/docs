When selecting a SHA, you should verify it is from the action's repository and not a repository fork.
