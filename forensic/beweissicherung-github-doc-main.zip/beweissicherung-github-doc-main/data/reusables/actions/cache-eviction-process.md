If you exceed the limit, {% data variables.product.prodname_dotcom %} will save the new cache but will begin evicting caches until the total size is less than the repository limit.
