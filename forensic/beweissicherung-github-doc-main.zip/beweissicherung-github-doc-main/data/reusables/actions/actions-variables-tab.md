1. Click the **Variables** tab.
