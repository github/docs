 Any unused labels that are not assigned to a runner will be automatically deleted within 24 hours.
