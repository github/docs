Variables allow you to store non-sensitive information, such as a username, in your repository, repository environments, or organization.
