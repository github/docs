Secrets allow you to store sensitive information, such as access tokens, in your repository, repository environments, or organization.
