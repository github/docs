A runner is a server that runs your workflows when they're triggered.
