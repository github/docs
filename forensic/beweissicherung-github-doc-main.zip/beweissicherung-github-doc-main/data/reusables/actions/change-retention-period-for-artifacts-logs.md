1. {% ifversion ghes %}In the "Artifact, log, and cache settings" section, u{% else %}U{% endif %}nder **Artifact and log retention**, enter a new value.
1. Click **Save** to apply the change.
