1. Navigate to {% data variables.product.login_url %}.
1. To prompt two-factor authentication, type your username and password, then click **Sign in**.
{% ifversion fpt or ghec %}

   > [!NOTE]
   > If you have linked a social account to your {% data variables.product.github %} account, you can sign-in with your social login instead of using your password.

{% endif %}
1. Under "More options", click **2FA recovery code**.
