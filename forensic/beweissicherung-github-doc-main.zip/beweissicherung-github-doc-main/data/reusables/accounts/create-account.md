1. Go to {% data variables.product.company_short %}'s [Pricing]({% data variables.product.pricing_url %}) page.
1. Read the information about the different products and subscriptions that {% data variables.product.company_short %} offers, then click the upgrade button under the subscription you'd like to choose.
