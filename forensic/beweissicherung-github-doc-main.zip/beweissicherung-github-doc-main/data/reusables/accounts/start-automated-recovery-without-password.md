1. You will be prompted for your 2FA credentials. Under "More options", click **Begin account or email recovery**.
1. In the modal that appears, click **I understand, get started**.
