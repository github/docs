{% data variables.product.github %} occasionally sends the following types of marketing emails:

* Tips and tricks for getting started with your account
* Customized information about engaging projects or new features
* Newsletters that you've subscribed to
