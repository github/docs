1. Under "More options", click **Begin account or email recovery**.
1. In the modal that appears, click **I understand, get started**.
1. You may be required to verify an email address. To send an email containing a one-time password to each email address associated with your account, click **Send one-time password**.
   > [!NOTE]
   > The one-time password will be sent to your primary and backup email addresses. Unless you have previously chosen a specific backup email address, all verified emails are considered backup email addresses.
1. Type the one-time password from your email in the "One-time password" text field, then click **Verify email address**.
