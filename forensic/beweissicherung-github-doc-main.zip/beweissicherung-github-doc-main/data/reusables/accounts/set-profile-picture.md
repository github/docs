1. Under "Profile Picture", select **{% octicon "pencil" aria-hidden="true" aria-label="pencil" %} Edit**, then click **Upload a photo...**.

   ![Screenshot of the "Public profile" section of a user account's settings. A button, labeled with a pencil icon and "Edit", is outlined in dark orange.](/assets/images/help/profile/edit-profile-photo.png)
1. Select an image, then click **Upload**.
1. Crop your picture.
1. Click **Set new profile picture**.
