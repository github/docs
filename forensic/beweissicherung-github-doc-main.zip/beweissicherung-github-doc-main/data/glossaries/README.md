# Glossaries

* `external.yml` contains customer-facing glossary entries.
  * Strings within `external.yml` support Liquid conditionals. See [contributing/liquid-helpers.md](/contributing/liquid-helpers.md).
* `candidates.yml` contains terms that should potentially be in the external glossary but haven't been defined yet.
