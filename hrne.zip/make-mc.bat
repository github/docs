call set_net2.bat
nmake make-mc
copy hrn.dll c:\inetpub\wwwroot\DmoTern
