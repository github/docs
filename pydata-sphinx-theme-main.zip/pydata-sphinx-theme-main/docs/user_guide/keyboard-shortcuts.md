# Keyboard shortcuts

## Trigger the search bar

You can trigger the search bar pop-up with {kbd}`Ctrl`/{kbd}`⌘` + {kbd}`K`.
