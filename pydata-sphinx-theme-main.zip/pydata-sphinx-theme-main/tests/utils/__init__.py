"""Utility functions for testing pydata-sphinx-theme."""
