"""Test conf file."""

# -- Project information -----------------------------------------------------

project = "Test"
copyright = "Test"
author = "Test"

# -- General configuration ---------------------------------------------------

root_doc = "index"

# -- Options for HTML output -------------------------------------------------

html_theme = "pydata_sphinx_theme"
