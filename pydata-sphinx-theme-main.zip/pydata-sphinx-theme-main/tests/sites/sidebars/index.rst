Sidebar depth variations
========================

.. toctree::
   :caption: Caption 1

   section1/index


.. toctree::
   :caption: Caption 2

   section2/index

Other content
-------------

This is some other content.
