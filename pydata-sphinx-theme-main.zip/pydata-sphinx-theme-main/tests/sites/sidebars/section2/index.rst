Section 2 index
===============

.. toctree::

   page1
   https://google.com


Other Content
-------------

This is some other content
