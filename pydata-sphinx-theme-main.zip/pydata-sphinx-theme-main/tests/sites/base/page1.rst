Page 1
======

**normal link**

- https://pydata-sphinx-theme.readthedocs.io/en/latest/

**GitHub**

.. container:: github-container

    https://github.com
    https://github.com/pydata
    https://github.com/pydata/pydata-sphinx-theme
    https://github.com/pydata/pydata-sphinx-theme/pull/1012
    https://github.com/orgs/pydata/projects/2

**GitLab**

.. container:: gitlab-container

    https://gitlab.com
    https://gitlab.com/gitlab-org
    https://gitlab.com/gitlab-org/gitlab
    https://gitlab.com/gitlab-org/gitlab/-/issues/375583
    https://gitlab.com/gitlab-org/gitlab/issues/375583
    https://gitlab.com/gitlab-org/gitlab/-/issues/
    https://gitlab.com/gitlab-org/gitlab/issues/
    https://gitlab.com/gitlab-org/gitlab/-/issues
    https://gitlab.com/gitlab-org/gitlab/issues
    https://gitlab.com/gitlab-org/gitlab/-/merge_requests/84669
    https://gitlab.com/gitlab-org/gitlab/-/pipelines/511894707
    https://gitlab.com/gitlab-com/gl-infra/production/-/issues/6788
