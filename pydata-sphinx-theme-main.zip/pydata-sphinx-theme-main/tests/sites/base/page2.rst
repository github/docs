:html_theme.sidebar_secondary.remove: true

Page :math:`\beta`
==================

.. code-block:: python

    import pydata_sphinx_theme as pst
    raise RuntimeError('Test of pygments highlighting')
