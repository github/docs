Index ``with code`` in title
============================

.. toctree::
   :caption: My caption
   :numbered:

   page1
   page2
   section1/index
   google <https://google.com>

A header
--------

A sub-header
~~~~~~~~~~~~

A sub-sub-header
````````````````
