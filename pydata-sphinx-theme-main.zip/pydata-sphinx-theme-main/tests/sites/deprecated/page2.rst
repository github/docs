:html_theme.sidebar_secondary.remove: true

Page :math:`\beta`
==================
