Index ``with code`` in title
============================

.. toctree::
   :caption: My caption
   :numbered:

   hansel/gretel/house

A header
--------

A sub-header
~~~~~~~~~~~~

A sub-sub-header
````````````````
