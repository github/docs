"""Tests for pydata-sphinx-theme."""
