// TODO: @trallard might end up moving this to the main JS file
// Define the custom behavior of the page

import "@fortawesome/fontawesome-free/js/all.min.js";
